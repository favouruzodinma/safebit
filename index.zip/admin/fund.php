<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require_once '../_db.php';
require '../PHPMailer/src/Exception.php';
require '../PHPMailer/src/PHPMailer.php';
require '../PHPMailer/src/SMTP.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['fundwallet'])) {
    try {
        // Assuming proper validation for user input 
        $coinType = $_POST['coin_name'];
        $amountValue = floatval($_POST['amount_value']);
        $amountUSD = floatval($_POST['amount_usd']);
        $wallet = $_POST['wallet'];
        $userid = $_POST['userid'];
        $email = $_POST['email'];
        $flname = $_POST['flname'];

        // Check if amount-value and amount-usd are strictly equal
        if ($amountValue === $amountUSD) {
            // Update user's balance in the user_login table based on the coin type
            $updateQuery = "UPDATE user_login SET {$coinType}_balance = {$coinType}_balance + ? WHERE userid = ?";
            $stmt = $conn->prepare($updateQuery);

            if ($stmt) {
                $stmt->bind_param("di", $amountValue, $userid);
                $stmt->execute();

                if ($stmt->affected_rows > 0) {
                    // Insert the updated balance into the history table
                    $insertQuery = "INSERT INTO history (userid, updated_balance, coinType, wallet, updated_at) VALUES (?, ?, ?, ?, NOW())";
                    $stmtInsert = $conn->prepare($insertQuery);

                    if ($stmtInsert) {
                        $updatedBalance = $amountValue; // Calculate updated balance

                        $stmtInsert->bind_param("sdss", $userid, $updatedBalance, $coinType, $wallet);
                        $stmtInsert->execute();

                        if ($stmtInsert->affected_rows > 0) {
                            // Email notification to the user using PHPMailer
                            $mail = new PHPMailer(true);
                            $mail->setFrom('safebit99@gmail.com', 'SafeBit Wallet');
                            $mail->addAddress($email, $flname);
                            $mail->Subject = 'Funds Added to Your Wallet';
                            $mail->Body = "Your SAFEBIT $coinType Wallet was funded with $amountValue $coinType. Thank you!";
                            $mail->send();

                            header("Location: success?userid=$userid");
                            exit();
                        } else {
                            echo "Failed to insert updated balance into history table.";
                        }

                        $stmtInsert->close();
                    } else {
                        echo "Prepare statement error for inserting into history table: " . $conn->error;
                    }
                } else {
                    echo "No rows were updated!";
                }

                $stmt->close();
            } else {
                echo "Prepare statement error: " . $conn->error;
            }
        } else {
            echo "Amount-value and amount-usd must be strictly equal!";
        }
    } catch (Exception $e) {
        echo "An error occurred: " . $e->getMessage();
    }
}
?>
