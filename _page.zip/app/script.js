document.getElementById('showErrorBtn').addEventListener('click', function() {
    document.getElementById('errorPopup').style.display = 'block';
});

document.getElementById('closeErrorBtn').addEventListener('click', function() {
    document.getElementById('errorPopup').style.display = 'none';
});
